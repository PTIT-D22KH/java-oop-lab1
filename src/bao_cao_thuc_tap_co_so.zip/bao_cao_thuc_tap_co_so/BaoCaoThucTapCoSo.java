/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bao_cao_thuc_tap_co_so;

import java.util.*;
import java.io.*;

/**
 *
 * @author P51
 */
public class BaoCaoThucTapCoSo {
    public static void main(String[] args) throws IOException{
//        Scanner input1 = new Scanner(new File("src/file_container/bao_cao_thuc_tap_co_so/SINHVIEN.in"));
//        Scanner input2 = new Scanner(new File("src/file_container/bao_cao_thuc_tap_co_so/DETAI.in"));
//        Scanner input3 = new Scanner(new File("src/file_container/bao_cao_thuc_tap_co_so/HOIDONG.in"));

        Scanner input1 = new Scanner(new File("SINHVIEN.in"));
        Scanner input2 = new Scanner(new File("DETAI.in"));
        Scanner input3 = new Scanner(new File("HOIDONG.in"));
        
        ArrayList<Student> students = new ArrayList<>();
        ArrayList<Topic> topics = new ArrayList<>();
        ArrayList<Commitee> commitees = new ArrayList<>();
        
        int n = Integer.parseInt(input1.nextLine());
        for (int i = 0; i < n; i++) {
            students.add(new Student(input1.nextLine(), input1.nextLine(), input1.nextLine(), input1.nextLine()));
        }
        int m = Integer.parseInt(input2.nextLine());
        for (int i = 0; i < m; i++) {
            topics.add(new Topic(input2.nextLine(), input2.nextLine()));
        }
        int p = Integer.parseInt(input3.nextLine());
        for (int i = 0; i < p; i++) {
            commitees.add(new Commitee(input3.nextLine()));
        }
        for (Commitee x : commitees) {
            for (Student y : students ) {
                if (y.getStudentId().equals(x.getStudentId())) {
                    for (Topic z : topics) {
                        if (z.getTopicId().equals(x.getTopicId())) {
                            y.setTopic(z);
                            y.setCommitee(x);
                            break;
                        }
                    }
                    break;
                }
            }
        }
        Collections.sort(students);
        Collections.sort(commitees);
        TreeSet<Commitee> tsCommitees = new TreeSet<>(commitees);
        
        for (Commitee x : tsCommitees) {
            System.out.printf("DANH SACH HOI DONG %s:\n", x.getCommiteeId().charAt(2));
            for (Student y : students) {
                if (y.getCommitee().getCommiteeId().equals(x.getCommiteeId())) {
                    System.out.println(y);
                }
            }
        }
    }
}
